'''
Created on 5 janv. 2015

@author: MRO
'''
import logging
import os
import sys
import glob
import imp
import inspect
import cast
from cast.application import KnowledgeBase, ApplicationLevelExtension
from cast.application.internal import set_current_application
from cast.application.internal.find_plugins import get_plugins, call_application_level_extensions

def run(kb_name, application_name, engine=None):
    """
    Run current app level plugin on a kb/application
    """
    FORMAT = '%(message)s'
    logging.basicConfig(format=FORMAT, level=logging.DEBUG)
    
    # for auto-upgrade
    logging.root.setLevel(logging.DEBUG)
    
    kb = KnowledgeBase(kb_name, engine)
    application = kb.get_application(application_name)

    test_class_file_path = ''
    is_test_class = False
    import traceback
    stack = traceback.extract_stack()
    for element in stack:
        if is_test_class:
            test_class_file_path = element[0]
            break
        if element[2] == 'run' and element[3] == 'testMethod()':
            # next element is the unit test file
            is_test_class = True

    pathname = os.path.dirname(test_class_file_path)
    plugin_path = os.path.abspath(os.path.join(pathname, '..'))

    for filepath in glob.glob(plugin_path + '/*.py'):

        temp = os.path.split(filepath)
        module_name, _ = os.path.splitext(temp[-1])
        try:
            sys.path.append(plugin_path)
            if module_name in sys.modules:
                del sys.modules[module_name]
            module = imp.load_source(module_name, filepath)
            plugin = None
            for name in dir(module):
                member = getattr(module, name)
                if inspect.isclass(member) and member.__module__ != 'cast.application' and issubclass(member, ApplicationLevelExtension):
                    if not plugin:
                        plugin_directory = temp[0]
                        plugin = cast.Plugin(plugin_directory)
                        get_plugins().append(plugin)
                    extension = member()
                    plugin.register_extension(extension)
            
                    plugin.__execution_context = (sys.modules.copy(), sys.path.copy())
            
        except Exception:
            print(traceback.format_exc())
            # may be normal because we also have python/C++ bindings
            # other way of avoiding it is to empty declare those bindings
            pass
    
    set_current_application(application)
    
    for plugin in get_plugins():
        
        plugin.set_temporary('')
        plugin.set_intermediate('')
        
    call_application_level_extensions('end_application', application)
