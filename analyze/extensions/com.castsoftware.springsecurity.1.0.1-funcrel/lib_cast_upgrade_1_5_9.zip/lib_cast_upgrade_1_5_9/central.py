import logging, re
from sqlalchemy import select
from . import CastSchema
from .internal.reflect import reflect_table 


class CentralBase(CastSchema):
    """
    A connection to a central base
    """
    
    def __init__(self, name, engine=None):
        
        CastSchema.__init__(self, name, engine)
        self._package_name = "ADG_CENTRAL"
        
        self.dss_objects = reflect_table('DSS_OBJECTS', self.metadata, self.engine)
        self.dss_object_info = reflect_table('DSS_OBJECT_INFO', self.metadata, self.engine)
        self.dss_translation = reflect_table('DSS_TRANSLATION_TABLE', self.metadata, self.engine)
        self.dss_snapshots = reflect_table('DSS_SNAPSHOTS', self.metadata, self.engine)
    
    def __repr__(self):
        return 'CentralBase(%s)' % self.name
    
    def get_applications(self):
        """
        Access to applications.
        
        .. versionadded:: 1.5.8
        """
        query = select([self.dss_objects.c.object_id, 
                        self.dss_objects.c.object_name]).where(self.dss_objects.c.object_type_id == -102)
        
        result = []
        by_id = {}
        
        for line in self._execute_sqlalchemyquery(query):
            application = Application(line[0], line[1], self)
            result.append(application)
            by_id[line[0]] = application
        
        setattr(self, 'applications_by_id', by_id)
        
        return result
    
    def get_application(self, name):
        """
        Access to application by name.
        
        .. versionadded:: 1.5.8
        """
        
        for application in self.get_applications():
            if application.name == name:
                return application
        
        
    def get_snapshots(self):
        """
        Access to snapshots.
        
        @return: .Snapshot
        """
        
        query = select([self.dss_snapshots.c.snapshot_id, 
                        self.dss_snapshots.c.application_id,
                        self.dss_snapshots.c.snapshot_name])
    
        result = []
    
        for line in self._execute_sqlalchemyquery(query):
            
            result.append(Snapshot(line[0], line[2], line[1]))
    
        return result
        

class Application:
    """
    Application in the central base.
    
    .. versionadded:: 1.5.8
    """
    def __init__(self, identifier, name, central):
        
        self.name = name
        self.id = identifier
        self.central = central
        self.managment = None # managment base associated with the application
        
    def get_central(self):
        """
        Central base of the application.
        """
        return self.central

    def get_managment_base(self):
        """
        Access to managment base.
        
        :return: :class:`cast.application.managment.ManagmentBase`
    
        WARNING : 
           this version only works for combined install on the same server.
           Future version of CAIP will leverage this limitation.
           
           Not working on sqlserver
        
        .. versionadded:: 1.5.8
        """
        if not hasattr(self, 'managment'):
            setattr(self, 'managment', None)
        
        if not self.managment:
            
            central_name = self.central.name

            if not central_name:
                # ms with database encoded in the connectio nstring ...
                url = str(self.kb.engine.url)
                result = re.search('DATABASE=(.*);', url)
                central_name = result.group(1)
                print(central_name)
            
            if central_name.lower().endswith('_central'):
                # case sensisitve ms
                if central_name.endswith('_central'):
                    postfix = '_mngt'
                else:
                    postfix = '_MNGT'
                
                mngt_name = central_name[:-8] + postfix
                from .managment import ManagmentBase
                self.managment = ManagmentBase(mngt_name, self.central.engine) 
        
        if not self.managment:
            logging.warning('get_managment_base is only working for combined installs')
            
        return self.managment

    def get_application_configuration(self):
        """
        Access to managment base application.
        
        :return: :class:`cast.application.managment.Application`
    
        WARNING : 
           this version only works for combined install on the same server.
           Future version of CAIP will leverage this limitation.
        
        .. versionadded:: 1.5.8
        """
        try:
            mngt = self.get_managment_base()
            return mngt.get_application(self.name)
        except:
            logging.warning('get_application_configuration is unsupported')
            return None

    def __repr__(self):
        
        return 'Application(%s)' % self.name
    
    def _run_amt_saver(self):
        """For compat"""
        pass
    
    
class Snapshot:
    
    def __init__(self, identifier, name, application_id):
        
        self.name = name
        self.id = identifier
            
    